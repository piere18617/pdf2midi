export type NDArray = any;
