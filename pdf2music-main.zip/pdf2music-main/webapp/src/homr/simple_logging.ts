export function eprint(...args: any[]): void {
  console.warn(...args);
}
