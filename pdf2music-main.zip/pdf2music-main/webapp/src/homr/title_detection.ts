export async function detectTitle(): Promise<string> {
  return "";
}

export async function downloadOcrWeights(): Promise<void> {}
