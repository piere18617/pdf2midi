"""Convert MusicXML to MIDI using music21."""

from __future__ import annotations

import os


def musicxml_to_midi(musicxml_path: str, midi_path: str) -> str:
    """Parse *musicxml_path* with music21 and write a ``.mid`` file."""
    from music21 import converter

    score = converter.parse(musicxml_path)
    midi_path = os.path.abspath(midi_path)
    score.write("midi", fp=midi_path)
    return midi_path
