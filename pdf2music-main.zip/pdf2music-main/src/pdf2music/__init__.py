"""pdf2music: convert PDF music scores to MusicXML / MIDI (offline, via homr)."""

__version__ = "0.1.0"
