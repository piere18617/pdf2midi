"""Run the homr OMR engine on a rendered PNG to produce MusicXML."""

from __future__ import annotations

import os
import sys
from dataclasses import dataclass


@dataclass
class HomrResult:
    musicxml_path: str
    return_code: int
    log: str


def _musicxml_path_for(image_path: str) -> str:
    return os.path.splitext(image_path)[0] + ".musicxml"


def run_homr(
    image_path: str,
    *,
    coreml_encoder: bool = False,
    metronome: int | None = None,
    debug: bool = False,
) -> HomrResult:
    """Invoke homr's public CLI entry point in-process on *image_path*.

    homr writes ``<stem>.musicxml`` next to the input image. We call its
    ``main`` function directly (after adjusting ``sys.argv``) so we reuse the
    same interpreter/venv and avoid subprocess overhead. Model weights are
    downloaded automatically on first use.
    """
    from homr import main as homr_main

    # Silence chatty third-party loggers; homr reports progress via eprint.
    import logging

    for name in ("RapidOCR", "onnxruntime", "urllib3"):
        logging.getLogger(name).setLevel(logging.WARNING)

    argv = ["homr", image_path]
    if coreml_encoder:
        argv.append("--coreml-encoder")
    if metronome is not None:
        argv.append("--output-metronome")
        argv.append(str(metronome))
    if debug:
        argv.append("--debug")

    log_lines: list[str] = []
    real_stderr = sys.stderr

    class _Catcher:
        """Forward homr progress to the terminal while keeping a copy."""

        def write(self, data: str) -> int:
            log_lines.append(data)
            real_stderr.write(data)
            return len(data)

        def flush(self) -> None:
            real_stderr.flush()

    old_argv = sys.argv
    old_stderr = sys.stderr
    sys.argv = argv
    sys.stderr = _Catcher()
    code = 0
    try:
        homr_main.main()
    except SystemExit as exc:
        code = int(exc.code) if exc.code is not None else 0
    except Exception as exc:
        raise RuntimeError(
            f"homr failed: {exc}\n--- homr log ---\n{''.join(log_lines)}"
        ) from exc
    finally:
        sys.argv = old_argv
        sys.stderr = old_stderr

    return HomrResult(
        musicxml_path=_musicxml_path_for(image_path),
        return_code=code,
        log="".join(log_lines),
    )
