"""pdf2music: convert a PDF music score into MusicXML and/or MIDI.

Pipeline:
    PDF --render--> PNG (all pages stacked) --homr--> MusicXML --music21--> MIDI

The OMR engine is `homr <https://github.com/liebharc/homr>`_, a state-of-the-art
transformer + segmentation based recognizer that runs fully offline (Apple
CoreML is used automatically on Apple Silicon).
"""

from __future__ import annotations

import argparse
import os
import shutil
import sys
import tempfile
from pathlib import Path

from pdf2music.midi_convert import musicxml_to_midi
from pdf2music.omr import run_homr
from pdf2music.pdf_render import render_pdf_to_png


def _eprint(*args: object) -> None:
    print(*args, file=sys.stderr)


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="pdf2music",
        description=(
            "Convert a PDF music score to MusicXML and/or MIDI using the "
            "state-of-the-art offline OMR engine 'homr'."
        ),
    )
    parser.add_argument("input", help="Path to the input PDF (or PNG/JPG) score")
    parser.add_argument(
        "-o",
        "--output",
        default=None,
        help="Directory to write outputs into (default: next to the input file).",
    )
    parser.add_argument(
        "-f",
        "--format",
        choices=["musicxml", "midi", "both"],
        default="both",
        help="Output format (default: both).",
    )
    parser.add_argument(
        "--coreml-encoder",
        action="store_true",
        help=(
            "On Apple Silicon, run the transformer encoder on the GPU via CoreML. "
            "Slow one-time compile (~30-60s); only helps across many images."
        ),
    )
    parser.add_argument(
        "--metronome",
        type=int,
        default=None,
        help="Add a metronome marking (BPM) to the generated MusicXML.",
    )
    parser.add_argument(
        "--dpi",
        type=int,
        default=300,
        help="DPI used when rendering the PDF to an image (default: 300).",
    )
    parser.add_argument(
        "--keep-png",
        action="store_true",
        help="Keep the intermediate rendered PNG next to the outputs.",
    )
    parser.add_argument(
        "--debug",
        action="store_true",
        help="Enable homr debug output (writes extra debug images).",
    )
    parser.add_argument(
        "--open",
        action="store_true",
        help="Open the output directory in Finder when finished.",
    )
    return parser


def _is_image(path: str) -> bool:
    return path.lower().endswith((".png", ".jpg", ".jpeg"))


def _stem(path: str) -> str:
    return os.path.splitext(os.path.basename(path))[0]


def convert(input_path: str, args: argparse.Namespace) -> list[str]:
    input_path = os.path.abspath(input_path)
    if not os.path.isfile(input_path):
        raise FileNotFoundError(f"Input not found: {input_path}")

    out_dir = os.path.abspath(args.output) if args.output else os.path.dirname(input_path)
    os.makedirs(out_dir, exist_ok=True)

    stem = _stem(input_path)
    produced: list[str] = []

    with tempfile.TemporaryDirectory(prefix="pdf2music_") as tmp:
        tmp_dir = tmp

        # 1. Get a raster image for homr (render PDF, or copy an existing image).
        if _is_image(input_path):
            work_image = os.path.join(tmp_dir, os.path.basename(input_path))
            shutil.copyfile(input_path, work_image)
        else:
            work_image = os.path.join(tmp_dir, stem + ".png")
            _eprint(f"[1/3] Rendering PDF to image at {args.dpi} DPI ...")
            n_pages = render_pdf_to_png(input_path, work_image, dpi=args.dpi)
            _eprint(f"      Rendered {n_pages} page(s).")

        # 2. Run homr -> MusicXML.
        _eprint("[2/3] Running OMR (homr) ... this may take a few minutes.")
        result = run_homr(
            work_image,
            coreml_encoder=args.coreml_encoder,
            metronome=args.metronome,
            debug=args.debug,
        )
        if not os.path.isfile(result.musicxml_path):
            # Surface whatever homr logged if it failed to produce output.
            raise RuntimeError(
                f"homr did not produce a MusicXML file.\n--- homr log ---\n{result.log}"
            )
        _eprint(f"      Wrote {os.path.basename(result.musicxml_path)}")

        # 3. Optionally convert to MIDI.
        if args.format in ("musicxml", "both"):
            dest_xml = os.path.join(out_dir, stem + ".musicxml")
            shutil.copyfile(result.musicxml_path, dest_xml)
            produced.append(dest_xml)
            _eprint(f"      -> {dest_xml}")

        if args.format in ("midi", "both"):
            midi_in_tmp = os.path.splitext(result.musicxml_path)[0] + ".mid"
            _eprint("[3/3] Converting MusicXML to MIDI (music21) ...")
            musicxml_to_midi(result.musicxml_path, midi_in_tmp)
            dest_mid = os.path.join(out_dir, stem + ".mid")
            shutil.copyfile(midi_in_tmp, dest_mid)
            produced.append(dest_mid)
            _eprint(f"      -> {dest_mid}")

        if args.keep_png:
            dest_png = os.path.join(out_dir, stem + ".png")
            shutil.copyfile(work_image, dest_png)
            produced.append(dest_png)

    return produced


def main(argv: list[str] | None = None) -> int:
    parser = build_parser()
    args = parser.parse_args(argv)

    try:
        produced = convert(args.input, args)
    except FileNotFoundError as exc:
        _eprint(f"error: {exc}")
        return 2
    except Exception as exc:  # noqa: BLE001
        _eprint(f"error: {exc}")
        return 1

    print("\nDone. Output(s):")
    for path in produced:
        print(f"  {path}")

    if args.open:
        try:
            import subprocess

            subprocess.run(["open", os.path.dirname(produced[0])], check=False)
        except Exception:  # noqa: BLE001
            pass
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
