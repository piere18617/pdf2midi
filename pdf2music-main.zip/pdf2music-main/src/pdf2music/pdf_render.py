"""Render a PDF score into a single high-resolution PNG image.

homr (the OMR engine pinned at 0.7.0) only accepts raster images, so we render
every page of the PDF and vertically stack them into one image -- mirroring the
multi-page handling found in homr's own (unreleased) ``pdf_utils`` module.
"""

from __future__ import annotations

import os

import cv2
import numpy as np
import pypdfium2 as pdfium

from homr.autocrop import autocrop

from pdf2music.type_definitions import NDArray


def _pad_to_width(page: NDArray, max_width: int) -> NDArray:
    width = page.shape[1]
    left = (max_width - width) // 2
    right = max_width - width - left
    return cv2.copyMakeBorder(
        page, 0, 0, left, right, cv2.BORDER_CONSTANT, value=(255, 255, 255)
    )


def _vstack_pages(pages: list[NDArray]) -> NDArray:
    if not pages:
        raise ValueError("PDF contained no renderable pages")
    max_width = max(page.shape[1] for page in pages)
    return np.vstack([_pad_to_width(page, max_width) for page in pages])


def render_pdf_to_png(pdf_path: str, png_path: str, dpi: int = 300) -> int:
    """Render every page of *pdf_path* into a single PNG at *png_path*.

    Returns the number of pages rendered.
    """
    scale = dpi / 72.0
    pdf = pdfium.PdfDocument(pdf_path)
    if not pdf:
        raise ValueError(f"Invalid or empty PDF: {pdf_path}")
    try:
        pages: list[NDArray] = []
        for page in pdf:
            bitmap = page.render(scale=scale)
            rgb = np.array(bitmap.to_pil().convert("RGB"))
            bgr = cv2.cvtColor(rgb, cv2.COLOR_RGB2BGR)
            pages.append(autocrop(bgr))
    finally:
        pdf.close()

    stacked = _vstack_pages(pages)
    ok = cv2.imwrite(png_path, stacked)
    if not ok:
        raise RuntimeError(f"Failed to write rendered PNG to {png_path}")
    return len(pages)
