"""Allow ``python -m pdf2music``."""

from pdf2music.cli import main

if __name__ == "__main__":
    raise SystemExit(main())
