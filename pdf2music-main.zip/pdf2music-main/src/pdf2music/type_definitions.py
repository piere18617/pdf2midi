"""Shared type aliases."""

from __future__ import annotations

import numpy as np

NDArray = np.ndarray
